# Blogging & Social Engagement Platform - MERN

Full Stack MERN Blog with:
- Post CRUD with Rich Text (React Quill)
- Likes, Comments (Mongoose population)
- User Profiles, JWT Auth
- Image Upload (Multer)
- Responsive Tailwind UI

## Run Backend
cd server
npm install
mkdir uploads
cp .env.example .env -> set MONGO_URI
npm run dev

## Run Frontend
cd client
npm install
REACT_APP_API_URL=http://localhost:5000/api npm start

## MongoDB Schemas
User -> Post (author ref), Post -> Comment, User likes array
Population used: .populate('author').populate('likes')

Deploy: Atlas + Render + Vercel
