import { useState, useEffect } from 'react';
import api from '../utils/api';
export default function CommentSection({ postId }){
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const load = async () => { const { data } = await api.get(`/posts/${postId}/comments`); setComments(data); };
  useEffect(()=>{ load(); }, [postId]);
  const submit = async (e) => {
    e.preventDefault();
    if(!text.trim()) return;
    await api.post(`/posts/${postId}/comments`, { text });
    setText(''); load();
  };
  return (
    <div className='mt-8'>
      <h4 className='font-bold mb-3'>Comments ({comments.length})</h4>
      <form onSubmit={submit} className='flex gap-2 mb-4'>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder='Add a comment...' className='flex-1 border p-2 rounded-lg'/>
        <button className='bg-black text-white px-4 rounded-lg'>Post</button>
      </form>
      <div className='space-y-3'>
        {comments.map(c=>(
          <div key={c._id} className='border p-3 rounded-lg bg-gray-50'>
            <p className='text-sm font-semibold'>{c.author?.username}</p>
            <p>{c.text}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
