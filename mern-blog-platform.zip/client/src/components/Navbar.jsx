import { Link, useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
export default function Navbar(){
  const { user, logout } = useContext(AuthContext);
  const nav = useNavigate();
  return (
    <nav className='flex justify-between items-center p-4 border-b bg-white sticky top-0 z-10'>
      <Link to='/' className='font-bold text-xl'>BlogSpace.</Link>
      <div className='flex gap-4 items-center'>
        <Link to='/'>Home</Link>
        {user ? <>
          <Link to='/create' className='bg-black text-white px-4 py-1 rounded-full'>Write</Link>
          <Link to={`/profile/${user._id}`}>{user.username}</Link>
          <button onClick={()=>{logout(); nav('/');}} className='text-red-500'>Logout</button>
        </> : <>
          <Link to='/login'>Login</Link>
          <Link to='/register' className='bg-black text-white px-4 py-1 rounded-full'>Sign up</Link>
        </>}
      </div>
    </nav>
  )
}
