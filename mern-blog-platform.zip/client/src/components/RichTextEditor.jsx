import ReactQuill from 'react-quill';
export default function RichTextEditor({ value, onChange }){
  const modules = { toolbar: [[{ header: [1,2,3,false]}], ['bold','italic','underline'], [{ list: 'ordered'}, { list: 'bullet'}], ['link','image'], ['clean']] };
  return <ReactQuill theme='snow' value={value} onChange={onChange} modules={modules} className='bg-white h-64 mb-12'/>;
}
