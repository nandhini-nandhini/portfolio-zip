import { Link } from 'react-router-dom';
export default function PostCard({ post }){
  return (
    <Link to={`/post/${post._id}`} className='border p-4 rounded-xl hover:shadow-lg transition bg-white'>
      {post.coverImage && <img src={`http://localhost:5000${post.coverImage}`} alt='' className='w-full h-48 object-cover rounded-lg mb-3'/>}
      <h3 className='font-bold text-lg'>{post.title}</h3>
      <p className='text-sm text-gray-600 line-clamp-2'>{post.excerpt || post.content.replace(/<[^>]*>/g,'').slice(0,120)}</p>
      <div className='flex justify-between mt-3 text-xs text-gray-500'>
        <span>by {post.author?.username}</span>
        <span>{post.likes?.length} likes</span>
      </div>
    </Link>
  )
}
