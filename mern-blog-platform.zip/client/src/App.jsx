import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import PostDetail from './pages/PostDetail';
import CreatePost from './pages/CreatePost';
import Auth from './pages/Auth';
import Profile from './pages/Profile';
export default function App(){
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className='min-h-screen bg-gray-50'>
          <Navbar/>
          <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path='/post/:id' element={<PostDetail/>}/>
            <Route path='/create' element={<CreatePost/>}/>
            <Route path='/edit/:id' element={<CreatePost/>}/>
            <Route path='/login' element={<Auth mode='login'/>}/>
            <Route path='/register' element={<Auth mode='register'/>}/>
            <Route path='/profile/:id' element={<Profile/>}/>
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  )
}
