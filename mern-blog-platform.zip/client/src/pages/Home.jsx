import { useEffect, useState } from 'react';
import api from '../utils/api';
import PostCard from '../components/PostCard';
export default function Home(){
  const [posts, setPosts] = useState([]);
  const [search, setSearch] = useState('');
  useEffect(()=>{
    const fetchPosts = async () => {
      const { data } = await api.get(`/posts?search=${search}`);
      setPosts(data);
    };
    fetchPosts();
  }, [search]);
  return (
    <div className='max-w-6xl mx-auto p-4'>
      <div className='py-10'>
        <h1 className='text-4xl font-bold'>Stories & Ideas</h1>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder='Search posts...' className='mt-4 border p-2 rounded-lg w-full max-w-md'/>
      </div>
      <div className='grid md:grid-cols-3 gap-6'>
        {posts.map(p=><PostCard key={p._id} post={p}/>)}
      </div>
    </div>
  )
}
