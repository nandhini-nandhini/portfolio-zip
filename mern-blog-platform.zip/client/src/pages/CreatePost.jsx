import { useState, useContext } from 'react';
import api from '../utils/api';
import RichTextEditor from '../components/RichTextEditor';
import { useNavigate, useParams } from 'react-router-dom';
export default function CreatePost(){
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [uploading, setUploading] = useState(false);
  const nav = useNavigate();
  const handleUpload = async (e) => {
    const file = e.target.files[0];
    const form = new FormData(); form.append('image', file);
    setUploading(true);
    const { data } = await api.post('/upload', form);
    setCoverImage(data.url); setUploading(false);
  };
  const submit = async (e) => {
    e.preventDefault();
    const { data } = await api.post('/posts', { title, content, coverImage, excerpt: content.replace(/<[^>]*>/g,'').slice(0,160) });
    nav(`/post/${data._id}`);
  };
  return (
    <div className='max-w-3xl mx-auto p-6'>
      <h2 className='text-2xl font-bold mb-4'>Create New Story</h2>
      <form onSubmit={submit} className='space-y-4'>
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder='Post title...' className='w-full border p-3 rounded-lg text-xl font-bold' required/>
        <input type='file' onChange={handleUpload} className='border p-2 rounded'/>
        {uploading && <p>Uploading...</p>}
        {coverImage && <img src={`http://localhost:5000${coverImage}`} alt='' className='w-full h-64 object-cover rounded'/>}
        <RichTextEditor value={content} onChange={setContent}/>
        <button className='bg-black text-white px-6 py-2 rounded-full mt-16'>Publish</button>
      </form>
    </div>
  )
}
