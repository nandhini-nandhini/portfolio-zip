import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../utils/api';
import PostCard from '../components/PostCard';
export default function Profile(){
  const { id } = useParams();
  const [data, setData] = useState(null);
  useEffect(()=>{ api.get(`/users/${id}`).then(r=>setData(r.data)); }, [id]);
  if(!data) return <p className='p-4'>Loading...</p>;
  return (
    <div className='max-w-6xl mx-auto p-6'>
      <div className='border p-6 rounded-xl bg-white mb-6'>
        <h2 className='text-2xl font-bold'>{data.user.username}</h2>
        <p className='text-gray-600'>{data.user.bio || 'Writer at BlogSpace.'}</p>
        <p className='text-sm mt-2'>{data.user.email}</p>
      </div>
      <h3 className='font-bold mb-3'>Posts by {data.user.username} ({data.posts.length})</h3>
      <div className='grid md:grid-cols-3 gap-6'>
        {data.posts.map(p=><PostCard key={p._id} post={p}/>)}
      </div>
    </div>
  )
}
