import { useEffect, useState, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { AuthContext } from '../context/AuthContext';
import CommentSection from '../components/CommentSection';
export default function PostDetail(){
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const { user } = useContext(AuthContext);
  const nav = useNavigate();
  useEffect(()=>{ api.get(`/posts/${id}`).then(r=>setPost(r.data)); }, [id]);
  const like = async () => { const { data } = await api.put(`/posts/${id}/like`); setPost({...post, likes: Array(data.likes).fill(0)}); };
  const del = async () => { await api.delete(`/posts/${id}`); nav('/'); };
  if(!post) return <p className='p-4'>Loading...</p>;
  return (
    <div className='max-w-3xl mx-auto p-6'>
      <h1 className='text-3xl font-bold'>{post.title}</h1>
      <p className='text-gray-500 mt-2'>by {post.author?.username} • {new Date(post.createdAt).toLocaleDateString()}</p>
      {post.coverImage && <img src={`http://localhost:5000${post.coverImage}`} alt='' className='w-full rounded-xl mt-6'/>}
      <div className='prose mt-6' dangerouslySetInnerHTML={{ __html: post.content }} />
      <div className='flex gap-3 mt-6'>
        <button onClick={like} className='border px-4 py-1 rounded-full'>❤️ {post.likes?.length} Likes</button>
        {user?._id === post.author?._id && <>
          <button onClick={()=>nav(`/edit/${post._id}`)} className='border px-4 py-1 rounded-full'>Edit</button>
          <button onClick={del} className='bg-red-500 text-white px-4 py-1 rounded-full'>Delete</button>
        </>}
      </div>
      <CommentSection postId={id}/>
    </div>
  )
}
