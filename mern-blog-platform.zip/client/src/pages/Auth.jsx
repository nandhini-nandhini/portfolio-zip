import { useState, useContext } from 'react';
import api from '../utils/api';
import { AuthContext } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
export default function Auth({ mode }){
  const [form, setForm] = useState({ username:'', email:'', password:'' });
  const { setUser, setToken } = useContext(AuthContext);
  const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    const endpoint = mode === 'login' ? '/auth/login' : '/auth/register';
    const { data } = await api.post(endpoint, form);
    setUser(data.user); setToken(data.token); nav('/');
  };
  return (
    <div className='max-w-md mx-auto mt-20 p-6 border rounded-xl bg-white'>
      <h2 className='text-2xl font-bold mb-4'>{mode === 'login' ? 'Welcome back' : 'Join BlogSpace'}</h2>
      <form onSubmit={submit} className='space-y-3'>
        {mode === 'register' && <input placeholder='Username' value={form.username} onChange={e=>setForm({...form, username:e.target.value})} className='w-full border p-2 rounded' required/>}
        <input placeholder='Email' type='email' value={form.email} onChange={e=>setForm({...form, email:e.target.value})} className='w-full border p-2 rounded' required/>
        <input placeholder='Password' type='password' value={form.password} onChange={e=>setForm({...form, password:e.target.value})} className='w-full border p-2 rounded' required/>
        <button className='w-full bg-black text-white p-2 rounded-full'>{mode === 'login' ? 'Login' : 'Create account'}</button>
      </form>
      <p className='text-sm mt-3 text-center'>{mode==='login'?<>No account? <Link to='/register' className='underline'>Register</Link></>:<>Have account? <Link to='/login' className='underline'>Login</Link></>}</p>
    </div>
  )
}
