import express from 'express';
import Post from '../models/Post.js';
import Comment from '../models/Comment.js';
import { protect } from '../middleware/auth.js';
const router = express.Router();

// Get all posts with author population
router.get('/', async (req, res) => {
  const { search, tag } = req.query;
  let query = {};
  if (search) query.title = { $regex: search, $options: 'i' };
  if (tag) query.tags = tag;
  const posts = await Post.find(query).populate('author', 'username avatar').sort({ createdAt: -1 });
  res.json(posts);
});

router.get('/:id', async (req, res) => {
  const post = await Post.findById(req.params.id).populate('author', 'username bio avatar').populate('likes', 'username');
  if (!post) return res.status(404).json({ message: 'Not found' });
  res.json(post);
});

router.post('/', protect, async (req, res) => {
  const { title, content, excerpt, coverImage, tags } = req.body;
  const post = await Post.create({ title, content, excerpt, coverImage, tags, author: req.userId });
  const populated = await post.populate('author', 'username avatar');
  res.status(201).json(populated);
});

router.put('/:id', protect, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ message: 'Not found' });
  if (post.author.toString() !== req.userId) return res.status(403).json({ message: 'Not allowed' });
  Object.assign(post, req.body);
  await post.save();
  res.json(await post.populate('author', 'username avatar'));
});

router.delete('/:id', protect, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ message: 'Not found' });
  if (post.author.toString() !== req.userId) return res.status(403).json({ message: 'Not allowed' });
  await Comment.deleteMany({ post: post._id });
  await post.deleteOne();
  res.json({ message: 'Deleted' });
});

// Like toggle
router.put('/:id/like', protect, async (req, res) => {
  const post = await Post.findById(req.params.id);
  const idx = post.likes.findIndex(id => id.toString() === req.userId);
  if (idx === -1) post.likes.push(req.userId);
  else post.likes.splice(idx, 1);
  await post.save();
  res.json({ likes: post.likes.length, liked: idx === -1 });
});

// Comments
router.get('/:id/comments', async (req, res) => {
  const comments = await Comment.find({ post: req.params.id }).populate('author', 'username avatar').sort({ createdAt: -1 });
  res.json(comments);
});

router.post('/:id/comments', protect, async (req, res) => {
  const comment = await Comment.create({ post: req.params.id, author: req.userId, text: req.body.text });
  res.status(201).json(await comment.populate('author', 'username avatar'));
});

export default router;
