import express from 'express';
import upload from '../middleware/upload.js';
import { protect } from '../middleware/auth.js';
const router = express.Router();

router.post('/', protect, upload.single('image'), (req, res) => {
  res.json({ url: `/uploads/${req.file.filename}` });
});

export default router;
