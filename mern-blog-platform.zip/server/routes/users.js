import express from 'express';
import User from '../models/User.js';
import Post from '../models/Post.js';
import { protect } from '../middleware/auth.js';
const router = express.Router();

router.get('/:id', async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');
  const posts = await Post.find({ author: req.params.id }).sort({ createdAt: -1 });
  res.json({ user, posts });
});

router.put('/profile', protect, async (req, res) => {
  const user = await User.findByIdAndUpdate(req.userId, req.body, { new: true }).select('-password');
  res.json(user);
});

export default router;
