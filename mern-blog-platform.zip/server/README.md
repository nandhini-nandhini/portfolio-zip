# Blog Server
npm install
cp .env.example .env
mkdir uploads
npm run dev