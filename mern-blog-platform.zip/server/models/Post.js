import mongoose from 'mongoose';
const postSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true }, // rich text HTML
  excerpt: { type: String },
  coverImage: { type: String, default: '' },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  tags: [{ type: String }],
}, { timestamps: true });
postSchema.index({ title: 'text', content: 'text' });
export default mongoose.model('Post', postSchema);
